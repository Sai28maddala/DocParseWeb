from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import pymupdf as fitz  # PyMuPDF
import pymongo
import re
from typing import List, Dict, Any, Optional
import tempfile
import os
from datetime import datetime
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
import nltk
from openai import OpenAI
import numpy as np
import json

app = FastAPI(title="DocParse", description="Lightweight research paper parsing demo")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize OpenAI client
# the newest OpenAI model is "gpt-5" which was released August 7, 2025.
# do not change this unless explicitly requested by the user
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
if OPENAI_API_KEY:
    openai_client = OpenAI(api_key=OPENAI_API_KEY)
else:
    openai_client = None

# MongoDB connection (optional)
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/")
try:
    mongo_client = pymongo.MongoClient(MONGO_URI)
    db = mongo_client.docparse
    feedback_collection = db.feedback
except Exception:
    mongo_client = None
    db = None
    feedback_collection = None

# Download NLTK data
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
except Exception:
    pass

# PDF processing functions
class PDFParser:
    @staticmethod
    def extract_title(doc) -> str:
        """Extract title from the first page - typically the largest text block"""
        try:
            page = doc[0]  # First page
            blocks = page.get_text("dict")["blocks"]
            
            # Find text blocks and sort by font size
            text_blocks = []
            for block in blocks:
                if "lines" in block:
                    for line in block["lines"]:
                        for span in line["spans"]:
                            if span["text"].strip():
                                text_blocks.append({
                                    "text": span["text"].strip(),
                                    "size": span["size"],
                                    "bbox": span["bbox"]
                                })
            
            # Sort by font size and position (top of page first)
            text_blocks.sort(key=lambda x: (-x["size"], x["bbox"][1]))
            
            # Return the largest text block that's not too short
            for block in text_blocks:
                if len(block["text"]) > 10 and not block["text"].isnumeric():
                    return block["text"]
                    
            return "Title not found"
        except Exception:
            return "Title extraction failed"
    
    @staticmethod
    def extract_authors(doc) -> List[str]:
        """Extract authors from the first page"""
        try:
            page = doc[0]
            text = page.get_text()
            
            # Look for common author patterns after title
            lines = text.split('\n')
            author_lines = []
            
            # Simple heuristic: authors are typically in the first few lines after title
            # and before abstract, often containing names with proper capitalization
            for i, line in enumerate(lines[:20]):  # Check first 20 lines
                line = line.strip()
                if line and len(line) < 150:  # Not too long
                    # Check if it looks like author names
                    words = line.split()
                    if len(words) >= 2 and len(words) <= 8:
                        # Check if it has name-like pattern
                        if any(word[0].isupper() and len(word) > 1 for word in words):
                            # Avoid common non-author lines
                            if not any(skip in line.lower() for skip in ['abstract', 'university', 'department', 'email', '@', '.com', 'figure', 'table']):
                                author_lines.append(line)
            
            return author_lines[:3] if author_lines else ["Authors not found"]
        except Exception:
            return ["Author extraction failed"]
    
    @staticmethod
    def extract_abstract(doc) -> str:
        """Extract abstract section"""
        try:
            full_text = ""
            for page in doc:
                full_text += page.get_text() + "\n"
            
            # Look for abstract section
            abstract_pattern = r'(?i)abstract[:\s]*\n?(.*?)(?=\n\s*(?:keywords|introduction|1\.|i\.|background|related work))'
            match = re.search(abstract_pattern, full_text, re.DOTALL | re.MULTILINE)
            
            if match:
                abstract = match.group(1).strip()
                # Clean up the text
                abstract = re.sub(r'\s+', ' ', abstract)
                return abstract[:1000]  # Limit length
            
            return "Abstract not found"
        except Exception:
            return "Abstract extraction failed"
    
    @staticmethod
    def extract_references(doc) -> List[str]:
        """Extract references section"""
        try:
            full_text = ""
            for page in doc:
                full_text += page.get_text() + "\n"
            
            # Look for references section
            ref_pattern = r'(?i)(?:references|bibliography)[:\s]*\n?(.*?)(?=\n\s*(?:appendix|acknowledgment)|\Z)'
            match = re.search(ref_pattern, full_text, re.DOTALL | re.MULTILINE)
            
            if match:
                refs_text = match.group(1).strip()
                # Split into individual references
                refs = []
                lines = refs_text.split('\n')
                current_ref = ""
                
                for line in lines:
                    line = line.strip()
                    if line:
                        # Check if this starts a new reference (numbered or author-year pattern)
                        if re.match(r'^\[\d+\]|\d+\.|\[[A-Z]', line) or (len(current_ref) > 0 and re.match(r'^[A-Z][a-z]+,?\s+[A-Z]', line)):
                            if current_ref:
                                refs.append(current_ref.strip())
                            current_ref = line
                        else:
                            current_ref += " " + line
                
                if current_ref:
                    refs.append(current_ref.strip())
                
                return refs[:10] if refs else ["References not found"]
            
            return ["References section not found"]
        except Exception:
            return ["Reference extraction failed"]
        
    @staticmethod
    def extract_keywords(doc) -> List[str]:
        """Extract keywords from the PDF"""
        try:
            full_text = ""
            for page in doc:
                full_text += page.get_text() + "\n"
            
            # First try to find explicit keywords section
            keywords_pattern = r'(?i)keywords?[:\s]*\n?(.*?)(?=\n\s*(?:introduction|1\.|i\.|background|abstract)|\n\n)'
            match = re.search(keywords_pattern, full_text, re.DOTALL | re.MULTILINE)
            
            if match:
                keywords_text = match.group(1).strip()
                keywords = re.split(r'[;,\n]', keywords_text)
                keywords = [k.strip() for k in keywords if k.strip() and len(k.strip()) > 2]
                if keywords:
                    return keywords[:10]
            
            # Fallback: extract TF-IDF keywords from abstract or beginning
            try:
                # Use first 2000 characters
                text_sample = full_text[:2000]
                # Clean text
                text_sample = re.sub(r'[^a-zA-Z\s]', ' ', text_sample)
                text_sample = ' '.join(text_sample.split())
                
                if len(text_sample) > 50:
                    vectorizer = TfidfVectorizer(max_features=10, stop_words='english', ngram_range=(1,2))
                    tfidf_matrix = vectorizer.fit_transform([text_sample])
                    feature_names = vectorizer.get_feature_names_out()
                    # Convert sparse matrix to 1D array of scores
                    try:
                        scores = np.asarray(tfidf_matrix.toarray(), dtype=float).ravel()  # type: ignore
                    except AttributeError:
                        # Fallback for non-sparse matrices
                        scores = np.asarray(tfidf_matrix, dtype=float).ravel()
                    
                    # Sanitize scores to handle any NaN values
                    scores = np.nan_to_num(scores, nan=0.0)
                    
                    # Get top keywords
                    keyword_scores = list(zip(feature_names, scores))
                    keyword_scores.sort(key=lambda x: x[1], reverse=True)
                    
                    return [kw[0] for kw in keyword_scores[:8] if kw[1] > 0]
            except Exception:
                pass
                
            return ["Keywords not found"]
        except Exception:
            return ["Keyword extraction failed"]
    
    @staticmethod
    def extract_journal_conference(doc) -> str:
        """Extract journal or conference name"""
        try:
            # Check first and last pages
            pages_to_check = [doc[0]]
            if len(doc) > 1:
                pages_to_check.append(doc[-1])
                
            for page in pages_to_check:
                text = page.get_text()
                
                # Common patterns for journals and conferences
                patterns = [
                    r'(?i)(?:published in|appears in|in proceedings of)\s*:?\s*([^\n]{10,80})',
                    r'(?i)(journal of [^\n]{5,50})',
                    r'(?i)(proceedings of [^\n]{5,50})',
                    r'(?i)(ieee [^\n]{5,50})',
                    r'(?i)(acm [^\n]{5,50})',
                    r'(?i)([^\n]*conference[^\n]{5,50})',
                    r'(?i)([^\n]*symposium[^\n]{5,50})',
                    r'(?i)([^\n]*workshop[^\n]{5,50})',
                ]
                
                for pattern in patterns:
                    matches = re.findall(pattern, text)
                    if matches:
                        # Clean and return the first reasonable match
                        venue = matches[0].strip()
                        venue = re.sub(r'\s+', ' ', venue)
                        if 10 < len(venue) < 100:
                            return venue
            
            return "Journal/Conference not found"
        except Exception:
            return "Journal/Conference extraction failed"
    
    @staticmethod
    def extract_publication_year(doc) -> str:
        """Extract publication year"""
        try:
            full_text = ""
            for page in doc:
                full_text += page.get_text() + "\n"
            
            # Look for year patterns (2000-2025)
            year_patterns = [
                r'\b(20[0-2][0-9])\b',  # 2000-2029
                r'\b(19[8-9][0-9])\b',  # 1980-1999
            ]
            
            years_found = []
            for pattern in year_patterns:
                years = re.findall(pattern, full_text)
                years_found.extend([int(y) for y in years])
            
            if years_found:
                # Filter reasonable years and get the most common
                current_year = datetime.now().year
                reasonable_years = [y for y in years_found if 1980 <= y <= current_year + 2]
                if reasonable_years:
                    year_counter = Counter(reasonable_years)
                    most_common_year = year_counter.most_common(1)[0][0]
                    return str(most_common_year)
            
            return "Year not found"
        except Exception:
            return "Year extraction failed"
    
    @staticmethod
    def count_references(references: List[str]) -> int:
        """Count the number of references"""
        try:
            # Filter out error messages
            valid_refs = [ref for ref in references if not any(
                error_msg in ref.lower() for error_msg in 
                ["not found", "failed", "extraction failed"]
            )]
            return len(valid_refs)
        except Exception:
            return 0

@app.get("/", response_class=HTMLResponse)
async def homepage():
    """Serve the main page"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>DocParse Web Application</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body { background-color: #f8f9fa; }
            .hero-section { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
            .upload-card { border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
            .result-section { background-color: white; border-radius: 10px; }
            .loading { display: none; }
            .metadata-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem; }
            .metadata-item { background: #f8f9fa; padding: 1rem; border-radius: 8px; border-left: 4px solid #007bff; }
        </style>
    </head>
    <body>
        <div class="hero-section py-5">
            <div class="container text-center">
                <h1 class="display-4 fw-bold">DocParse Web Application</h1>
                <p class="lead">Extract structured metadata from research papers with AI-powered analysis</p>
            </div>
        </div>

        <div class="container my-5">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <!-- Upload Section -->
                    <div class="card upload-card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h3 class="card-title mb-0">Upload PDF Document</h3>
                        </div>
                        <div class="card-body p-4">
                            <form id="uploadForm" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="pdfFile" class="form-label fw-semibold">Select PDF File</label>
                                    <input type="file" class="form-control" id="pdfFile" name="file" accept=".pdf" required>
                                    <div class="form-text">Choose a research paper in PDF format</div>
                                </div>
                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary btn-lg flex-fill">
                                        <span class="upload-text">Parse Document</span>
                                        <span class="loading">
                                            <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                                            Processing...
                                        </span>
                                    </button>
                                    <button type="button" id="summarizeBtn" class="btn btn-success btn-lg flex-fill" disabled>
                                        <span class="summarize-text">AI Summary</span>
                                        <span class="summarize-loading" style="display: none;">
                                            <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                                            Summarizing...
                                        </span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Results Section -->
                    <div id="results" class="mt-4" style="display: none;">
                        <div class="card result-section">
                            <div class="card-header bg-success text-white">
                                <h4 class="card-title mb-0">Parsing Results</h4>
                            </div>
                            <div class="card-body">
                                <div id="metadataDisplay" class="metadata-grid mb-4"></div>
                                <details>
                                    <summary class="fw-bold mb-2">Raw JSON Data</summary>
                                    <pre id="resultJson" class="bg-light p-3 rounded"></pre>
                                </details>
                            </div>
                        </div>
                    </div>

                    <!-- Summary Section -->
                    <div id="summarySection" class="mt-4" style="display: none;">
                        <div class="card">
                            <div class="card-header bg-info text-white">
                                <h4 class="card-title mb-0">AI Summary</h4>
                            </div>
                            <div class="card-body">
                                <div id="summaryContent" class="p-3 bg-light rounded"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Feedback Section -->
                    <div id="feedbackSection" class="mt-4" style="display: none;">
                        <div class="card">
                            <div class="card-header bg-warning text-white">
                                <h4 class="card-title mb-0">Submit Feedback</h4>
                            </div>
                            <div class="card-body">
                                <form id="feedbackForm">
                                    <div class="mb-3">
                                        <label for="feedbackText" class="form-label">Your feedback about the parsing results:</label>
                                        <textarea class="form-control" id="feedbackText" rows="4" placeholder="Share your thoughts about the accuracy and quality of the extracted data..."></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-warning">
                                        <span class="feedback-text">Submit Feedback</span>
                                        <span class="feedback-loading" style="display: none;">
                                            <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                                            Submitting...
                                        </span>
                                    </button>
                                </form>
                                <div id="feedbackMessage" class="mt-3" style="display: none;"></div>
                            </div>
                        </div>
                    </div>

                    <!-- About Section -->
                    <div class="card mt-4">
                        <div class="card-header">
                            <h4 class="card-title mb-0">About</h4>
                        </div>
                        <div class="card-body">
                            <p class="mb-0">DocParse is a lightweight research paper parsing demo that extracts comprehensive metadata including title, authors, abstract, references, keywords, publication details, and provides AI-powered summaries. Built with advanced text processing and machine learning techniques for accurate academic document analysis.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            let currentResults = null;

            document.getElementById('uploadForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const formData = new FormData();
                const fileInput = document.getElementById('pdfFile');
                const file = fileInput.files[0];
                
                if (!file) {
                    alert('Please select a PDF file');
                    return;
                }
                
                formData.append('file', file);
                
                // Show loading state
                document.querySelector('.upload-text').style.display = 'none';
                document.querySelector('.loading').style.display = 'inline';
                document.getElementById('uploadForm').querySelector('button[type="submit"]').disabled = true;
                document.getElementById('results').style.display = 'none';
                document.getElementById('summarySection').style.display = 'none';
                document.getElementById('feedbackSection').style.display = 'none';
                
                try {
                    const response = await fetch('/process', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    currentResults = result;
                    
                    if (response.ok) {
                        displayResults(result);
                        document.getElementById('results').style.display = 'block';
                        document.getElementById('feedbackSection').style.display = 'block';
                        document.getElementById('summarizeBtn').disabled = false;
                        document.getElementById('results').scrollIntoView({ behavior: 'smooth' });
                    } else {
                        alert('Error: ' + (result.detail || 'Processing failed'));
                    }
                } catch (error) {
                    alert('Error: ' + error.message);
                } finally {
                    // Reset loading state
                    document.querySelector('.upload-text').style.display = 'inline';
                    document.querySelector('.loading').style.display = 'none';
                    document.getElementById('uploadForm').querySelector('button[type="submit"]').disabled = false;
                }
            });

            function displayResults(result) {
                // Display formatted metadata
                const metadataHtml = `
                    <div class="metadata-item">
                        <h6 class="fw-bold text-primary">Title</h6>
                        <p class="mb-0">${result.title}</p>
                    </div>
                    <div class="metadata-item">
                        <h6 class="fw-bold text-primary">Authors</h6>
                        <p class="mb-0">${Array.isArray(result.authors) ? result.authors.join(', ') : result.authors}</p>
                    </div>
                    <div class="metadata-item">
                        <h6 class="fw-bold text-primary">Publication Year</h6>
                        <p class="mb-0">${result.publication_year || 'Not found'}</p>
                    </div>
                    <div class="metadata-item">
                        <h6 class="fw-bold text-primary">Journal/Conference</h6>
                        <p class="mb-0">${result.journal_conference || 'Not found'}</p>
                    </div>
                    <div class="metadata-item">
                        <h6 class="fw-bold text-primary">Keywords</h6>
                        <p class="mb-0">${Array.isArray(result.keywords) ? result.keywords.join(', ') : result.keywords}</p>
                    </div>
                    <div class="metadata-item">
                        <h6 class="fw-bold text-primary">Reference Count</h6>
                        <p class="mb-0">${result.reference_count} references</p>
                    </div>
                    <div class="metadata-item">
                        <h6 class="fw-bold text-primary">Abstract</h6>
                        <p class="mb-0">${result.abstract}</p>
                    </div>
                `;
                
                document.getElementById('metadataDisplay').innerHTML = metadataHtml;
                document.getElementById('resultJson').textContent = JSON.stringify(result, null, 2);
            }

            // AI Summary functionality
            document.getElementById('summarizeBtn').addEventListener('click', async function() {
                if (!currentResults) return;
                
                // Show loading state
                document.querySelector('.summarize-text').style.display = 'none';
                document.querySelector('.summarize-loading').style.display = 'inline';
                this.disabled = true;
                
                try {
                    const response = await fetch('/summarize', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            title: currentResults.title,
                            abstract: currentResults.abstract,
                            keywords: currentResults.keywords
                        })
                    });
                    
                    const result = await response.json();
                    
                    if (response.ok) {
                        document.getElementById('summaryContent').innerHTML = `<p>${result.summary}</p>`;
                        document.getElementById('summarySection').style.display = 'block';
                        document.getElementById('summarySection').scrollIntoView({ behavior: 'smooth' });
                    } else {
                        alert('Error generating summary: ' + (result.detail || 'Summarization failed'));
                    }
                } catch (error) {
                    alert('Error: ' + error.message);
                } finally {
                    // Reset loading state
                    document.querySelector('.summarize-text').style.display = 'inline';
                    document.querySelector('.summarize-loading').style.display = 'none';
                    this.disabled = false;
                }
            });

            // Feedback form functionality
            document.getElementById('feedbackForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const feedbackText = document.getElementById('feedbackText').value.trim();
                if (!feedbackText || !currentResults) return;
                
                // Show loading state
                document.querySelector('.feedback-text').style.display = 'none';
                document.querySelector('.feedback-loading').style.display = 'inline';
                document.getElementById('feedbackForm').querySelector('button').disabled = true;
                
                try {
                    const response = await fetch('/feedback', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            filename: currentResults.filename,
                            feedback: feedbackText
                        })
                    });
                    
                    const result = await response.json();
                    
                    if (response.ok) {
                        document.getElementById('feedbackMessage').innerHTML = 
                            '<div class="alert alert-success">Thank you for your feedback!</div>';
                        document.getElementById('feedbackText').value = '';
                    } else {
                        document.getElementById('feedbackMessage').innerHTML = 
                            '<div class="alert alert-danger">Error submitting feedback: ' + (result.detail || 'Failed') + '</div>';
                    }
                    
                    document.getElementById('feedbackMessage').style.display = 'block';
                } catch (error) {
                    document.getElementById('feedbackMessage').innerHTML = 
                        '<div class="alert alert-danger">Error: ' + error.message + '</div>';
                    document.getElementById('feedbackMessage').style.display = 'block';
                } finally {
                    // Reset loading state
                    document.querySelector('.feedback-text').style.display = 'inline';
                    document.querySelector('.feedback-loading').style.display = 'none';
                    document.getElementById('feedbackForm').querySelector('button').disabled = false;
                }
            });
        </script>
    </body>
    </html>
    """

@app.post("/process")
async def process_pdf(file: UploadFile = File(...)):
    """Process uploaded PDF and extract metadata"""
    
    # Validate file type and size
    if not file.filename or not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are allowed")
    
    # Check file size (limit to 50MB)
    content = await file.read()
    if len(content) > 50 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File too large. Maximum size is 50MB.")
    
    # Reset file position for re-reading
    await file.seek(0)
    
    temp_file_path = None
    try:
        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
            temp_file.write(content)
            temp_file_path = temp_file.name
        
        # Open PDF with PyMuPDF
        try:
            doc = fitz.open(temp_file_path)
        except Exception as pdf_error:
            if temp_file_path and os.path.exists(temp_file_path):
                os.unlink(temp_file_path)
            return JSONResponse(
                status_code=400,
                content={"detail": f"Invalid or corrupted PDF file: {str(pdf_error)}"}
            )
        
        # Extract metadata
        parser = PDFParser()
        
        references = parser.extract_references(doc)
        
        result = {
            "filename": file.filename,
            "pages": doc.page_count,
            "title": parser.extract_title(doc),
            "authors": parser.extract_authors(doc),
            "abstract": parser.extract_abstract(doc),
            "references": references,
            "keywords": parser.extract_keywords(doc),
            "journal_conference": parser.extract_journal_conference(doc),
            "publication_year": parser.extract_publication_year(doc),
            "reference_count": parser.count_references(references),
            "status": "success"
        }
        
        # Close document
        doc.close()
        
        # Clean up temporary file
        os.unlink(temp_file_path)
        
        return JSONResponse(content=result)
        
    except Exception as e:
        # Clean up temporary file if it exists
        try:
            if temp_file_path and os.path.exists(temp_file_path):
                os.unlink(temp_file_path)
        except:
            pass
        
        raise HTTPException(
            status_code=500, 
            detail=f"Error processing PDF: {str(e)}"
        )

@app.post("/summarize")
async def summarize_document(data: dict):
    """Generate AI summary of the document"""
    
    if not openai_client:
        # Return graceful fallback instead of error
        return JSONResponse(content={
            "summary": "AI summarization is currently unavailable. Please ensure OPENAI_API_KEY is configured."
        })
    
    try:
        title = data.get("title", "")
        abstract = data.get("abstract", "")
        keywords = data.get("keywords", [])
        
        # Prepare content for summarization
        content_parts = []
        if title and title != "Title not found":
            content_parts.append(f"Title: {title}")
        if abstract and abstract != "Abstract not found":
            content_parts.append(f"Abstract: {abstract}")
        if keywords and keywords != ["Keywords not found"]:
            if isinstance(keywords, list):
                content_parts.append(f"Keywords: {', '.join(keywords)}")
            else:
                content_parts.append(f"Keywords: {keywords}")
        
        if not content_parts:
            return JSONResponse(content={
                "summary": "Insufficient content available for summarization."
            })
        
        content = "\n\n".join(content_parts)
        
        # Create prompt for summarization
        prompt = f"""Please provide a concise 2-3 sentence summary of this research paper based on the following information:

{content}

Focus on the main contribution, methodology, or key findings. Keep it clear and accessible."""

        # Call OpenAI API with current model
        model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")  # Use available model
        try:
            response = openai_client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}]
            )
            
            # Get response content with null check
            content = response.choices[0].message.content
            summary = content.strip() if content else "Unable to generate summary"
            
            return JSONResponse(content={"summary": summary})
        except Exception as api_error:
            # Provide local fallback summary on API failure
            fallback_summary = "AI summarization failed. "
            if abstract and abstract != "Abstract not found":
                # Use first 200 characters of abstract as fallback
                fallback_summary += abstract[:200] + ("..." if len(abstract) > 200 else "")
            elif title and title != "Title not found":
                fallback_summary += f"This paper is titled '{title}'."
            else:
                fallback_summary += "Summary unavailable due to technical issues."
            
            return JSONResponse(content={"summary": fallback_summary})
        
    except Exception as e:
        # Final fallback for any unexpected errors
        return JSONResponse(content={
            "summary": "Summary generation encountered an unexpected error. Please try again later."
        })

@app.post("/feedback")
async def submit_feedback(filename: str = Form(...), feedback: str = Form(...)):
    """Submit user feedback about parsing results"""
    
    try:
        feedback_data = {
            "filename": filename,
            "feedback": feedback,
            "timestamp": datetime.utcnow()
        }
        
        # Try to save to MongoDB if available
        if feedback_collection is not None:
            try:
                feedback_collection.insert_one(feedback_data)
                return JSONResponse(content={
                    "status": "success", 
                    "message": "Feedback saved to database",
                    "stored": True
                })
            except Exception as db_error:
                # Log feedback to stdout as fallback
                print(f"Feedback (DB unavailable): {filename} - {feedback}")
                return JSONResponse(content={
                    "status": "success",
                    "message": "Feedback received (storage temporarily unavailable)",
                    "stored": False
                })
        else:
            # No database configured, log and acknowledge
            print(f"Feedback (No DB): {filename} - {feedback}")
            return JSONResponse(content={
                "status": "success",
                "message": "Feedback received",
                "stored": False
            })
            
    except Exception as e:
        # Final fallback for any unexpected errors
        print(f"Feedback error fallback: {filename} - {feedback}")
        return JSONResponse(content={
            "status": "success",
            "message": "Feedback received (processed with fallback handling)",
            "stored": False
        })

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)