# DocParse

## Overview

DocParse is a lightweight research paper parsing application built with FastAPI and PyMuPDF. The system focuses on extracting structured information from PDF documents, specifically targeting academic papers. The application provides REST API endpoints for uploading PDF files and extracting key metadata such as titles and authors from research papers.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Framework
- **FastAPI**: Chosen as the web framework for its automatic API documentation, type hints support, and high performance. FastAPI provides built-in validation and serialization, making it ideal for file upload and JSON response handling.

### PDF Processing Engine
- **PyMuPDF (fitz)**: Selected as the core PDF parsing library for its robust text extraction capabilities and ability to access font metadata. This enables intelligent title extraction based on font size analysis.

### Text Extraction Strategy
- **Font-based Title Detection**: The system uses a heuristic approach to identify paper titles by analyzing font sizes and positioning on the first page. Text blocks are sorted by font size and vertical position to prioritize title candidates.
- **Structured Data Extraction**: The parser extracts text as structured blocks with metadata (font size, bounding boxes) rather than plain text, enabling more intelligent content identification.

### API Design
- **RESTful Endpoints**: The application follows REST principles with clear separation between file upload handling and data processing.
- **Error Handling**: Comprehensive exception handling ensures graceful degradation when PDF parsing fails.

### File Handling
- **Temporary File Management**: Uses Python's tempfile module for secure handling of uploaded PDF files, ensuring automatic cleanup after processing.

## External Dependencies

### Core Libraries
- **FastAPI**: Web framework and API server
- **PyMuPDF (fitz)**: PDF document parsing and text extraction
- **Python Standard Library**: tempfile, os, re, typing modules for file handling and text processing

### Development Dependencies
- Standard Python development tools for a FastAPI application

### Deployment Considerations
- The application is designed as a lightweight service that can be easily containerized
- No database dependencies for core functionality
- Minimal external service requirements